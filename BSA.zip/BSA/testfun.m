fnlist = ['F1' 'F2' 'F3' 'F4' 'F5' 'F6'];
time = 30;

for fn=1:23
    fname = strcat('F', num2str(fn));
    [lb,ub,dim,fobj]=Get_Functions_details(fname);   
    popsize = 30;
    resfile = strcat('bsa', fname);
    resfile = strcat(resfile, '.txt');
    fid = fopen(resfile, 'w');
    
    for i=1:time
        res = bsa(fobj, fname, popsize, dim, lb, ub, 3000, i);    
        fprintf(fid,'%e\n',res);
    end  
    fclose(fid);
end