function [fname,fnc,low,up,dim]=settingOfBenchmarkFnc(i)
% i = 29;

i=6
load myfncsetting
textdata=myfncsetting.fnclist;
data=myfncsetting.fnc_LowUpDim;
textdata
%size(textdata)
fname=textdata(i,1);

fname=fname{1};
fname
fnc=eval(textdata{i,2});

low=data(6,1);
up=data(6,2);
dim=data(6,3);

% assignin('base','fname',fname);
% assignin('base','fnc',fnc);
% assignin('base','low',low);
% assignin('base','up',up);
% assignin('base','dim',dim);

return
