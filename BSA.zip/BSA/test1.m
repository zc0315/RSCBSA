% create a matrix y, with two rows
x = 0:10:100;
y = [x; log(x)];
 
% open a file for writing
fid = fopen('logtable.txt', 'w');
 
% Table Header
fprintf(fid, 'Log    Function');
 
% print values in column order
% two values appear on each row of the file
fprintf(fid, '\n%f    %f', y);
fclose(fid);
% display the file created
type logtable.txt
