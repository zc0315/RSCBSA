function [globalminimum]=bsa(fobj,fnc, popsize,dim,low,up,epoch,time)

%INITIALIZATION
if numel(low)==1, low=low*ones(1,dim); up=up*ones(1,dim); end % this line must be adapted to your problem
pop=GeneratePopulation(popsize,dim,low,up); % see Eq.1 in [1]
fitnesspop = zeros(1, popsize);
for i=1:popsize
    fitnesspop(1, i)=fobj(pop(i, :));
end

[~,ind]=min(fitnesspop);
globalminimizer=pop(ind, :);

historical_pop=GeneratePopulation(popsize,dim,low,up); % see Eq.2 in [1]
CR = 0.9;
% historical_pop  is swarm-memory of BSA as mentioned in [1].
%time
% ---------------------       --------------------------------------------------------------------- 
filename = strcat('bsarun', fnc);
filename = strcat(filename, '_');
filename = strcat(filename, num2str(time));
filename = strcat(filename, '.txt');
%filename
% open a file for writing
fid = fopen(filename, 'w');
% Table Header
fprintf(fid, 'epk     globalminimum\n');
for epk=1:epoch
    
    
    
    %SELECTION-I
    if rand<rand, historical_pop=pop; end  % see Eq.3 in [1]
    historical_pop=historical_pop(randperm(popsize),:); % see Eq.4 in [1]
    %����
    V = ones(popsize, dim);
    for r = 1:popsize
        i = randi(popsize);
        j = randi(popsize);
        while i == j
            j = randi(popsize);
        end
        k = randi(popsize);
        while i==k || j==k    
            k = randi(popsize);
        end
        m = randi(popsize);
        while i==m || j==m || k==m
            m =randi(popsize);
        end
        X(1,:)= pop(i,:);
        X(2,:)= pop(j,:);
        X(3,:)= pop(k,:);
        X(4,:)= pop(m,:);
        %X
        X_fitness = zeros(1, 3);
        for k=1:3
            X_fitness(1, k) = fobj(X(k, :));
        end
        
        %X_fitness
        fitnesssum = sum(X_fitness(1, 1:3));
        if fitnesssum == 0
            fitnesssum = 10e-6;
        end
        w1 = X_fitness(1) / (fitnesssum);
        w2 = X_fitness(2) / (fitnesssum);
        w3 = X_fitness(3) / (fitnesssum);
        
        Xog = w1*pop(i, :) + w2*pop(j, :) +w3*pop(k, :);
        %F = get_scale_factor();
        V(r, :) = globalminimizer  + (3*(1-epk/epoch))*sin(rand())*(Xog - pop(m,:));
    end
    
    V=BoundaryControl(V,low,up); 

    %����
    u = ones(popsize, dim);
    for i = 1:popsize
        randx = randperm(dim);  %[1,2,3,..D]���������    
        for j = 1:dim
            if rand > CR && randx(1) ~= j % CR =0.9
                u(i,j) = V(i,j);
            else
                u(i,j) = pop(i,j);
            end
        end
    end

    % SELECTON-II
    %fitnessoffsprings=feval(fnc,u,mydata);
    fitnessoffsprings = zeros(1, popsize);
    for k=1:popsize
        fitnessoffsprings(1, k) = fobj(u(k, :));
    end
    ind=fitnessoffsprings<fitnesspop;
    fitnesspop(ind)=fitnessoffsprings(ind);
    pop(ind,:)=u(ind,:);
    [globalminimum,ind]=min(fitnesspop);    
    globalminimizer=pop(ind,:);
    % threshold(1,epk) = b(1,ind);
    % EXPORT SOLUTIONS 
    assignin('base','globalminimizer',globalminimizer);
    assignin('base','globalminimum',globalminimum);
    fprintf(fid, '%f -----> %e\n',epk,globalminimum);
 % time = 2;
%   for epk=1:time  
%     bsa(fnc,[],popsize,dim,1,low,up,epoch);  %���������Ż�����
%   end
    % print values in column order
    % two values appear on each row of the file
    %fprintf(fid, '%f ', globalminimum);
      
end

fclose(fid);  
%display the file created
type filename;
return 




function pop=GeneratePopulation(popsize,dim,low,up)
pop=ones(popsize,dim);
for i=1:popsize
    for j=1:dim
        pop(i,j)=rand*(up(j)-low(j))+low(j);
    end
end
return

function pop=BoundaryControl(pop,low,up)
[popsize,dim]=size(pop);
for i=1:popsize
    for j=1:dim                
        k=rand<rand; % you can change boundary-control strategy
        if pop(i,j)<low(j), if k, pop(i,j)=low(j); else pop(i,j)=rand*(up(j)-low(j))+low(j); end, end        
        if pop(i,j)>up(j),  if k, pop(i,j)=up(j);  else pop(i,j)=rand*(up(j)-low(j))+low(j); end, end        
    end
end
return

function F=get_scale_factor() % you can change generation strategy of scale-factor,F    
      F=3*randn; % STANDARD brownian-walk
      %F=4*randg;  % brownian-walk    
      %F=lognrnd(rand,5*rand);  % brownian-walk              
      %F=1/normrnd(0,5);        % pseudo-stable walk (levy-like)
      %F=1./gamrnd(1,0.5);      % pseudo-stable walk (levy-like, simulates inverse gamma distribution; levy-distiribution)
return