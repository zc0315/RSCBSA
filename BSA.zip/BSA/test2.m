% x = rand(10, 30)*1200-600;
% x
% 
% i = round(rand()*10)+1;
% j = round(rand()*10)+1;
% while i == j
%     j=round(rand()*10)+1;
% end
% 
% k = round(rand()*10)+1;
% 
% while i==k || j == k
%     k = round(rand()*10)+1;
% end
% 
% m = round(rand()*10)+1;
% 
% while i==m || j==m || k==m
%     m = round(rand()*10)+1;
% end
% 
% w1 = griewank(x(i, :) , '') / (griewank(x(i, :) , '') + griewank(x(j, :) , '') + griewank(x(k, :) , ''));
% w2 = griewank(x(j, :) , '') / (griewank(x(i, :) , '') + griewank(x(j, :) , '') + griewank(x(k, :) , ''));
% w3 = griewank(x(k, :) , '') / (griewank(x(i, :) , '') + griewank(x(j, :) , '') + griewank(x(k, :) , ''));
% Xog = w1*griewank(x(i, :) , '') + w2*griewank(x(j, :) , '') + w3*griewank(x(k, :) , '');
% 
% F = 0.0001;
% V = Xog+F*(x(i,:) - x(m, :));
% 
% 
% for r=1:30
%     if V(1,r) < -600
%         V(1,r) = -600;
%     elseif V(1, r) > 600
%         V(1, r) = 600;
%     else
%         V(1,r) = V(1,r);
%     end
% end
% 
% ObjVal = griewank(V, '');
% 
% ObjVal      

fn = 'sin'
x = [pi pi/2 3*pi/2 2*pi];
fvalue = feval(fn, x);
fvalue

function [] = 